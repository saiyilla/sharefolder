col dt1 noprint new_value dt1

SELECT   TO_CHAR (SYSDATE, 'yyyymmdd-HH24MISS') dt1 FROM DUAL;

spool F:\babavali\LONG_RUNNING\LONG_RUNNING_QUERY_&dt1..log
@F:\babavali\db.sql
SET LINESIZE 200
SET PAGES 200
col OSUSER for a7
col sql for a8
col sql_text for a30
col CLIENT_INFO for a14
col EVENT for a7
col process for a10
col PROGRAM for a10
col MACHINE for a10
col action for a10
col status for a10
set lines 195 pages 9999
alter session set "_hash_join_enabled"=true;
select /*+ rule */ s.sid,s.serial# ,sa.sql_text,s.username sql,s.client_info,s.machine,
sw.event,sw.seconds_in_wait sec,s.program, s.process, s.osuser,s.sql_id,s.last_call_et
from gv$session_wait sw, gv$session s, gv$sqlarea sa
where sw.sid = s.sid (+)
and s.sql_address = sa.address
and s.username not in ('BANARJI')
and sw.event not in
('rdbms ipc message', 'smon timer', 'pmon timer', 'SQL*Net message from client',
'lock manager wait for remote message', 'client message', 'SQL*Net more data from client',
'pipe get','null event', 'PX Idle Wait', 'single-task message', 'wakeup time manager')
order by last_call_et 
/ 

btitle off
ttitle off
clear breaks
clear columns
clear computes
set verify on
spool off;
