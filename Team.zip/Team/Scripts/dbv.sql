spool E:\kbl_dbv.log
 set lines 165 pages 999
 select 'dbv file=' ||file_name|| ' logfile=file'||ROWNUM||'.log blocksize=8192' || ' feedback=' || round(blocks*.10,0) from dba_data_files;
