set lines 165 pages 999
col name for a50
select a.tablespace_name, a.FILE_ID, b.name, a.bytes_used/1024/1024, a.bytes_free/1024/1024 from v$temp_space_header a, v$tempfile b where a.file_id=b.file#;



