set lines 150 pages 999
col HOST_NAME for a22
col STARTUP_TIME for a35
select A.INSTANCE_NAME,B.NAME DB_NAME, A.HOST_NAME,B.OPEN_MODE, B.LOG_MODE, A.VERSION,to_char(STARTUP_TIME,'dd-mon-yyyy hh24:mi:ss') STARTUP_TIME from v$instance A, V$DATABASE B;
