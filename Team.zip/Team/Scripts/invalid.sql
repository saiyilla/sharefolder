col owner for a15
col OBJECT_NAME for a50
col object_type for a15
SELECT owner, object_type, object_name FROM dba_objects WHERE status = 'INVALID';