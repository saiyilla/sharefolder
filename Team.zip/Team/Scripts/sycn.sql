set lines 185 pages 9999
col STDBY_LATEST_TIME for a36
SELECT
        a.resetlogs_id,
        DECODE (a.thread#, 1, 'node1', 2, 'node2') HOST,
        b.last_seq prmy_last_file,
        a.applied_seq stdby_last_file,
        CASE WHEN b.last_seq - a.applied_seq > 50000 THEN '=>' ELSE to_char(b.last_seq - a.applied_seq) END archive_difference,
        TO_CHAR (a.latest_apply_time, 'dd/mm/yyyy hh24:mi:ss') stdby_latest_time
FROM
        (SELECT   resetlogs_id, thread#, MAX (sequence#) applied_seq, MAX (next_time) latest_apply_time
FROM
        v$archived_log
WHERE
        applied = 'YES'
        GROUP BY resetlogs_id, thread#) a,
        (SELECT   resetlogs_id, thread#, MAX (sequence#) last_seq
FROM
        v$archived_log
        GROUP BY resetlogs_id, thread#) b
WHERE
        a.thread# = b.thread#
        ORDER BY a.thread#
/