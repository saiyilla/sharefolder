set lines 180 pages 999
col OWNER for a10
col DB_LINK for a20
col HOST for a60
col USERNAME for a10
select * from dba_db_links;