set lines 170 pages 999
col tablespacename for a20
col file_name for a70
select file_name, bytes/1024/1024, tablespace_name,AUTOEXTENSIBLE  from dba_data_files where tablespace_name=('&TABLESPACE') order by file_name;
