select /*+ rule */ count(*)
 from gv$session_wait sw, gv$session s, gv$sqlarea sa
 where sw.sid = s.sid (+)
 and s.sql_address = sa.address
 and sw.event not in
 ('rdbms ipc message', 'smon timer', 'pmon timer', 'SQL*Net message from client',
 'lock manager wait for remote message', 'client message', 'SQL*Net more data from client',
 'pipe get','null event', 'PX Idle Wait', 'single-task message', 'wakeup time manager')
 order by last_call_et
/