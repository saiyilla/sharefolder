
select sum (bytes/1024/1024/1024) from dba_data_files;

select sum (bytes/1024/1024/1024) from dba_segments;

select sum (bytes/1024/1024/1024) from dba_free_space;