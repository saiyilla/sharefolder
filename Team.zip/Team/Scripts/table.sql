@F:\siluvai\frmarch.sql
@F:\siluvai\db.sql
col owner for a15
col segment_name for a35
 
select 
    * from 
    (select 
    owner, 
    segment_name, 
    segment_type,
    tablespace_name, 
    bytes/1024/1024/1024 GB 
    from 
    dba_segments 
    where 
    tablespace_name='MAY_FRM_ARCHIVE' 
    and
    segment_type='TABLE'
    order by 4 desc) 
where 
    ROWNUM<=10;
