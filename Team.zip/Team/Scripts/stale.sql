
COL OWNER FOR A15
COL TABLE_NAME FOR A35
SET LINES 165 PAGES 999
select
owner,
table_name,
stale_stats,
last_analyzed
from
dba_tab_statistics
where
stale_stats='YES'
and owner in ('TBAADM','CRMUSER','ALTADM','CUSTOM','SVSUSER','CXPSADM','JIRAADM','SADM','SISADM','KBLMPASSBOOK','MIS','KALYPTO_CREDIT_PROD','SYSADM') ORDER BY 2,4;
