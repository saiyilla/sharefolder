select count(*), to_char(completion_time,'DD-MON-YY') AS "DATE", 
sum(blocks*block_size)/1024/1024/1024 MB from v$archived_log WHERE 
to_char(completion_time,'DD-MON-YY')=to_char(SYSDATE-1,'DD-MON-YY')  
and STANDBY_DEST='NO'group by to_char(completion_time,'DD-MON-YY');
